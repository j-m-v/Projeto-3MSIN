package controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.ServletException;
//import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import model.CursoArtes;
import model.ListaCursoArtes;
import to.CursoArtesTO;

import util.JSonFacade;

public class ServicoManterAluno extends HttpServlet {
	
	private static final long serialVersionUID = 1L;
	 
	/*
	 * configurar a request e a response para todos os métodos
	 */
	@Override
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		response.setContentType("application/json");
		response.setCharacterEncoding("UTF-8");
		super.service(request, response);
	}
	/*
	 * listar alunos
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		String chave = request.getParameter("data[search]");
		ListaCursoArtes artes = new ListaCursoArtes();
		ArrayList<CursoArtesTO> lista;
		
		PrintWriter out = response.getWriter();

		try {
			if (chave != null && chave.length() > 0) {
				lista = artes.listarCursosArtes(chave);
			} else {
				lista = artes.listarCursosArtes();
			}
			out.println(JSonFacade.listToJSon(lista));
		} catch (Exception e) {
			e.printStackTrace();
			out.println(JSonFacade.errorToJSon(e));
		}
		
	}

	/*
	 * inclusão de alunos
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		StringBuilder sb = JSonFacade.montaJSon(request);
		PrintWriter out = response.getWriter();

		try {
			CursoArtes cursoArtes = JSonFacade.jSonToCursoArtes(sb.toString());
			cursoArtes.incluir();
			//retorna o cliente cadastrado com o id atribuido pelo banco
			out.println(JSonFacade.cursoArtesToJSon(cursoArtes));
		} catch (Exception e) {
			e.printStackTrace();
			out.println(JSonFacade.errorToJSon(e));
		}
	}
	/*
	 * atualiza clientes
	 */
	protected void doPut(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		StringBuilder sb = JSonFacade.montaJSon(request);
		PrintWriter out = response.getWriter();

		try {
			CursoArtes cursoArtes = JSonFacade.jSonToCursoArtes(sb.toString());
			cursoArtes.alterar();
			//retorna o cliente atualizado
			out.println(JSonFacade.cursoArtesToJSon(cursoArtes));
		} catch (Exception e) {
			e.printStackTrace();
			out.println(JSonFacade.errorToJSon(e));
		}
	}

	/*
	 * exclusão de clientes
	 */
	protected void doDelete(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		StringBuilder sb = JSonFacade.montaJSon(request);
		PrintWriter out = response.getWriter();

		try {
			CursoArtes cursoArtes = JSonFacade.jSonToCursoArtes(sb.toString());
			cursoArtes.deletar(); 
			//retorna dados null se o cliente foi deletado
			out.println(JSonFacade.cursoArtesToJSon(cursoArtes));
		} catch (Exception e) {
			e.printStackTrace();
			out.println(JSonFacade.errorToJSon(e));
		}
	}

	
}
