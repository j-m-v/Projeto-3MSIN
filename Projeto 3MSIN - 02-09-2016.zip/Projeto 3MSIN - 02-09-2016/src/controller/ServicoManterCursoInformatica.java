package controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.ServletException;
//import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import model.CursoInformatica;
import model.ListaCursoInformatica;
import to.CursoInformaticaTO;

import util.JSonFacade;

public class ServicoManterCursoInformatica extends HttpServlet {
	
	private static final long serialVersionUID = 1L;
	 
	/*
	 * configurar a request e a response para todos os métodos
	 */
	@Override
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		response.setContentType("application/json");
		response.setCharacterEncoding("UTF-8");
		super.service(request, response);
	}
	/*
	 * listar alunos
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		String chave = request.getParameter("data[search]");
		ListaCursoInformatica informatica = new ListaCursoInformatica();
		ArrayList<CursoInformaticaTO> lista;
		
		PrintWriter out = response.getWriter();

		try {
			if (chave != null && chave.length() > 0) {
				lista = informatica.listarCursosArtes(chave);
			} else {
				lista = informatica.listarCursosArtes();
			}
			out.println(JSonFacade.listToJSon(lista));
		} catch (Exception e) {
			e.printStackTrace();
			out.println(JSonFacade.errorToJSon(e));
		}
		
	}

	/*
	 * inclusão de alunos
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		StringBuilder sb = JSonFacade.montaJSon(request);
		PrintWriter out = response.getWriter();

		try {
			CursoInformatica cursoInformatica = JSonFacade.jSonToCursoArtes(sb.toString());
			cursoInformatica.incluir();
			//retorna o cliente cadastrado com o id atribuido pelo banco
			out.println(JSonFacade.cursoArtesToJSon(cursoInformatica));
		} catch (Exception e) {
			e.printStackTrace();
			out.println(JSonFacade.errorToJSon(e));
		}
	}
	/*
	 * atualiza clientes
	 */
	protected void doPut(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		StringBuilder sb = JSonFacade.montaJSon(request);
		PrintWriter out = response.getWriter();

		try {
			CursoInformatica cursoInformatica = JSonFacade.jSonToCursoInformatica(sb.toString());
			cursoInformatica.alterar();
			//retorna o cliente atualizado
			out.println(JSonFacade.cursoInformaticaToJSon(cursoInformatica));
		} catch (Exception e) {
			e.printStackTrace();
			out.println(JSonFacade.errorToJSon(e));
		}
	}

	/*
	 * exclusão de clientes
	 */
	protected void doDelete(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		StringBuilder sb = JSonFacade.montaJSon(request);
		PrintWriter out = response.getWriter();

		try {
			CursoInformatica cursoInformatica = JSonFacade.jSonToCursoInformatica(sb.toString());
			cursoInformatica.deletar(); 
			//retorna dados null se o cliente foi deletado
			out.println(JSonFacade.cursoInformaticaToJSon(cursoInformatica));
		} catch (Exception e) {
			e.printStackTrace();
			out.println(JSonFacade.errorToJSon(e));
		}
	}

	
}
