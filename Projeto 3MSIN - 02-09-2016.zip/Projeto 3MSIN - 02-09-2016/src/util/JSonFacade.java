package util;

import java.io.BufferedReader;
import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;


import model.CursoArtes;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import to.CursoArtesTO;

public class JSonFacade {
	
	public static StringBuilder montaJSon(HttpServletRequest request)
			throws IOException {
		StringBuilder sb = new StringBuilder();
		BufferedReader reader = request.getReader();
		try {
			String line;
			while ((line = reader.readLine()) != null) {
				sb.append(line).append('\n');
			}
		} finally {
			reader.close();
		}
		return sb;
	}

	public static String listToJSon(ArrayList<CursoArtesTO> lista) {
		JSONArray vetor = new JSONArray();
		for (CursoArtesTO to : lista) {
			JSONObject object = new JSONObject();
			try {
				object.put("id", to.getId());
				object.put("nome", to.getNome());
				object.put("livros", to.getLivros());
				object.put("dataInicio", to.getDataInicio());
				object.put("dataTermino", to.getDataTermino());
				object.put("horario", to.getHorario());
				object.put("valor", to.getValor());
				object.put("vagas", to.getVagas());
				object.put("descricao Material", to.getDescricaoMaterial());
				vetor.put(object);
			} catch (JSONException e) {
				e.printStackTrace();
			}
		}
		return vetor.toString();
	}

	public static CursoArtes jSonToCursoArtes(String json) throws IOException{
		try{
			JSONObject registro = new JSONObject(json);
			int id = registro.getInt("id");
			String nome = registro.getString("nome");
			String livros = registro.getString("livros");
			String dataInicio = registro.getString("dataInicio");
			String dataTermino = registro.getString("dataTermino");
			String horario = registro.getString("horario");
			int vagas = registro.getInt("vagas");
			int valor = registro.getInt("valor");
			String descricaoMaterial = registro.getString("Descricao Material");
			
			return new CursoArtes(id, nome, livros, dataInicio, dataTermino, horario, vagas, valor, descricaoMaterial);
		} catch(JSONException jsone){
			jsone.printStackTrace();
			throw new IOException(jsone);
		}
	}
	
	public static String cursoArtesToJSon(CursoArtes cursoArtes) throws IOException {
		JSONObject object = new JSONObject();
		try {
			object.put("id", cursoArtes.getId());
			object.put("nome", cursoArtes.getNome());
			object.put("livros", cursoArtes.getLivros());
			object.put("dataInicio", cursoArtes.getDataInicio());
			object.put("dataTermino", cursoArtes.getDataTermino());
			object.put("horario", cursoArtes.getHorario());
			object.put("valor", cursoArtes.getValor());
			object.put("vagas", cursoArtes.getVagas());
			object.put("descricao Material", cursoArtes.getDescricaoMaterial());
		} catch (JSONException e) {
			e.printStackTrace();
		}
		return object.toString();
	}

	public static String errorToJSon(Exception e) {
		JSONObject object = new JSONObject();
		try {
			object.put("error", e.toString());
		} catch (JSONException e1) {
			e.printStackTrace();
		}
		return object.toString();
	}
}
