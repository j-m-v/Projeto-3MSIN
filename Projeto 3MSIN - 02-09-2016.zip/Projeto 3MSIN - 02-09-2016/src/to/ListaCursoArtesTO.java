package to;

import java.util.ArrayList;

public class ListaCursoArtesTO {

	ArrayList<CursoArtesTO> cursosArtes;
	ArrayList<CursoInformaticaTO> cursosInformatica;

	public ArrayList<CursoArtesTO> getCursoArtes() {
		return cursosArtes;
	}

	public void setCursosArtes(ArrayList<CursoArtesTO> cursosArtes) {
		this.cursosArtes = cursosArtes;
	}
	


}
