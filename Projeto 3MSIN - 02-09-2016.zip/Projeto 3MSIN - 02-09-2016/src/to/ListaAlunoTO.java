package to;

import java.util.ArrayList;

public class ListaAlunoTO {
	ArrayList<AlunoTO> alunos;

	public ArrayList<AlunoTO> getAlunos() {
		return alunos;
	}

	public void setAlunos(ArrayList<AlunoTO> aluno) {
		this.alunos = aluno;
	}
	
}

