package to;

import java.util.ArrayList;

public class ListaCursoInformaticaTO {
	ArrayList<CursoInformaticaTO> cursosInformatica;

	
	public ArrayList<CursoInformaticaTO> getCursoInformatica() {
		return cursosInformatica;
	}

	public void setCursosInformatica(ArrayList<CursoInformaticaTO> cursosInformatica) {
		this.cursosInformatica = cursosInformatica;
	}

}
